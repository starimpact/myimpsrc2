
#ifndef _IMP_GA_LICENSE_MANAGER_H_
#define _IMP_GA_LICENSE_MANAGER_H_

#ifdef __cplusplus
extern "C"
{
#endif


IMP_S32 IMP_CheckLicenseByMac();


#ifdef __cplusplus
}
#endif


#endif
