#include "imp_pea_regionset_common.h"

IMP_VOID IMP_PEA_RGEDataClear( PEA_REGION_EXTRACT_DATA_S *pstData )
{
}