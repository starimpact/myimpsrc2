
#include "imp_avd_common.h"

//#define AVD_CHANGE_DIFF_TH  10
#define AVD_CHANGE_RATIO_TH  30
#define AVD_CHANGE_NO_PROCESS_FRM 1
#define AVD_CHANGE_MIN_FRM 1

IMP_S32 AVD_changeAnalysis( AVD_MODULE* avdModule );
