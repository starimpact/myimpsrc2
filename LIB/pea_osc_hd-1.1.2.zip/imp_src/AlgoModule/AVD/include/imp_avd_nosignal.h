
#include "imp_avd_common.h"

#define AVD_NOSIGNAL_L 70
#define AVD_NOSIGNAL_H 99
#define AVD_NOSIGNAL_MIN_CNT 5

void AVD_noSignalAnalysis( AVD_MODULE* avdModule );
