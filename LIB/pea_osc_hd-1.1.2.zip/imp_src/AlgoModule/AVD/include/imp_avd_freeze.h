

#include "imp_avd_common.h"

#define AVD_FREEZE_NO_PROCESS_FRM 2  
#define AVD_FREEZE_PIXEL_CNT 1	
#define AVD_FREEZE_MIN_FRM 5		

void AVD_freezeAnalysis( AVD_MODULE* avdModule );
