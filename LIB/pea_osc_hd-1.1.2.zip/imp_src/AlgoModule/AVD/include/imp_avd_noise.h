

#include "imp_avd_common.h"

#define AVD_PEPPER_TH	1
#define AVD_SALT_TH		30
#define AVD_NOISE_TH	4
#define AVD_NOISE_TH2	31

void AVD_noiseAnalysis( AVD_MODULE* avdModule );