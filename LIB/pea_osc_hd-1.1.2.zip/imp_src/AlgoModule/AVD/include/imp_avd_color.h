
#include "imp_avd_common.h"

#define AVD_COLOR_TH 10
#define AVD_COLOR_DELTA 2
void AVD_colorAnalysis( AVD_MODULE* avdModule );
