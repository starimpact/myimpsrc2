
#include "imp_avd_common.h"

#define AVD_CLARITY_EDGE_HT_IR 1
#define AVD_CLARITY_EDGE_HT    4

void AVD_clarityAnalysis( AVD_MODULE* avdModule );