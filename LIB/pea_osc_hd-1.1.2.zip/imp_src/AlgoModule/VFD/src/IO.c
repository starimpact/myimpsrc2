/** 
 * @brief	        ����ʶ�������������
 * @date			 2008/07/22
 * Copyright (C) 2004 WISEBIRD CO.,  All rights reserved.
 *
 *----------------------------------------------------------------------
 */

#include <math.h>
#include <time.h>
#include <errno.h>
#include "FaceDetectMain.h"
#include "IO.h"

#include <stdio.h>
#include <stdlib.h>

/*----------------------------------------------------------------------
  *  Internal declaration
----------------------------------------------------------------------*/
#define BINFILES


