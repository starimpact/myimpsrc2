#ifndef _PROCESS_AVD_H_
#define _PROCESS_AVD_H_

#include "hi_common.h"
#include "hi_comm_video.h"
#include "hi_comm_sys.h"
#include "mpi_sys.h"
#include "hi_comm_vb.h"
#include "mpi_vb.h"
#include "hi_comm_vi.h"
#include "mpi_vi.h"
#include "vo_open.h"

#include "hi_comm_vo.h"
#include "hi_comm_vi.h"
#include "hi_comm_vpp.h"
#include "hi_comm_venc.h"
#define MAX_FRM_CNT 256

#include "mpi_sys.h"
#include "mpi_vo.h"
#include "mpi_vpp.h"
#include "mpi_venc.h"


//typedef IpRect IP_RECT ;
//typedef IpLine IP_LINE ;

#ifdef __cplusplus
extern "C"
{
#endif



//void DrawAvdResult( VIDEO_FRAME_S *pVBuf, AVD_RESULT *pAvdResult);
//int AVD_ALGO_PROCESS();

#ifdef __cplusplus
}
#endif


#endif
